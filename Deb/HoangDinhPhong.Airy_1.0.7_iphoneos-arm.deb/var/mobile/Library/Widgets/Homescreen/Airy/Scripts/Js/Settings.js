function HDP(){checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', config.br + 'px');

/*Color*/
document.documentElement.style.setProperty('--timeCl', config.timeCl);

document.documentElement.style.setProperty('--batNameCl', config.batNameCl);

document.documentElement.style.setProperty('--weBgCl', config.weBgCl);

document.documentElement.style.setProperty('--calCl', config.calCl);

/*On Off*/
if(!config.Apps){
document.getElementById('Apps').style.display = 'none';
}
if(!config.Cal){
document.getElementById('CalCont').style.display = 'none';
}}