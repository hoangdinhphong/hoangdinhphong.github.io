function HDP(){checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', config.br + 'px');
if(!config.Apps){
document.getElementById('Apps').style.display = 'none';
}
if(!config.Cal){
document.getElementById('CalCont').style.display = 'none';
}}