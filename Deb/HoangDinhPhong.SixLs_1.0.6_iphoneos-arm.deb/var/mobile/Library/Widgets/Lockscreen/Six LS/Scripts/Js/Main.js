var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 480) { iPhoneType = "iPh4"; }
else if (screen.height == 568) { iPhoneType = "iPh5"; }
else if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh4":
document.body.style.width='320px';
document.body.style.height='480px';
$("#text").css({ "font-size":"15px" });
$("#Top").css({ "top":"-6.7%" });
$("#Clock").css({ "font-size":"50px" });
$("#Calendar").css({ "font-size":"12px" });
$("#Title").css({ "font-size":"12px" });
$("#City").css({ "font-size":"12px" });
$("#Controls").css({ "top":"82.1%" });
$("#PlayPause").css({ "font-size":"17px", "top":"-2px" });
$("#Prev, #Next").css({ "font-size":"12px" });
$("#RingLeft, #RingRight").css({ "width":"33px", "height":"33px" });
break;

case "iPh5":
document.body.style.width='320px';
document.body.style.height='568px';
$("#text").css({ "font-size":"15px" });
$("#Top").css({ "top":"-6.7%" });
$("#Clock").css({ "font-size":"60px" });
$("#Calendar").css({ "font-size":"14px" });
$("#Title").css({ "font-size":"14px" });
$("#City").css({ "font-size":"14px" });
$("#Controls").css({ "top":"82.4%" });
$("#PlayPause").css({ "font-size":"17px", "top":"-2px" });
$("#Prev, #Next").css({ "font-size":"12px" });
$("#RingLeft, #RingRight").css({ "width":"38px", "height":"38px" });
break;

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#City").css({ "font-size":"17px" });
$("#text").css({ "font-size":"18px" });
$("#Top").css({ "top":"-6.7%" });
$("#Clock").css({ "font-size":"70px" });
$("#Calendar").css({ "font-size":"17px" });
$("#Controls").css({ "top":"79.7%" });
$("#PlayPause").css({ "font-size":"16px", "top":"-2px" });
$("#Prev, #Next").css({ "font-size":"12px" });
$("#Bottom").css({ "height":"20.5%" });
$("#BotBox").css({ "height":"41%" });
$("#BotCenter").css({ "top":"39%", "height":"47%", "width": "81%" });
$("#RingLeft, #RingRight").css({ "width":"53px", "height":"53px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#text").css({ "font-size":"19px" });
$("#Top").css({ "top":"-6.7%" });
$("#Title, #City").css({ "top":"40%"});
$("#Calendar").css({ "top":"87%"});
$("#Clock").css({ "font-size":"75px" });
$("#Title, #City, #Calendar").css({ "font-size":"15px" });
$("#Controls").css({ "top":"83.1%" });
$("#Bottom").css({ "height":"17.6%" });
$("#BotBox").css({ "height":"51.1%" });
$("#BotCenter").css({ "height":"50.5%", "width":"83%" });
$("#RingLeft, #RingRight").css({ "width":"53px", "height":"53px" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#BotCenter").css({ "width": "81%" });
$("#RingLeft, #RingRight").css({ "width":"53px", "height":"53px" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#BotCenter").css({ "width": "81%" });
$("#RingLeft, #RingRight").css({ "width":"53px", "height":"53px" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#BotCenter").css({ "width": "81%" });
break;

case "editMode":
document.body.style.width='563px';
document.body.style.height='1000px';
screenWidth = 563;
break;}
}, false);