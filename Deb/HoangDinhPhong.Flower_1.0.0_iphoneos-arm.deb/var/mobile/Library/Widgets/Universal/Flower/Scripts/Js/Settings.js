document.documentElement.style.setProperty('--w', config.w + '%');
document.documentElement.style.setProperty('--h', config.h + '%');
document.documentElement.style.setProperty('--bl', config.bl + 'px');
document.documentElement.style.setProperty('--pbl', config.pbl + 'px');