/* Scale, brightness & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
document.documentElement.style.setProperty('--bri', config.bri + '%');
document.documentElement.style.setProperty('--bl', config.bl + 'px');

/* Color */
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--clockCirCl', config.clockCirCl + 'deg');
document.documentElement.style.setProperty('--calCirCl', config.calCirCl + 'deg');
document.documentElement.style.setProperty('--tempCirCl', config.tempCirCl + 'deg');
document.documentElement.style.setProperty('--weCirCl', config.weCirCl + 'deg');
document.documentElement.style.setProperty('--clockNameCl', config.clockNameCl);
document.documentElement.style.setProperty('--calNameCl', config.calNameCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--weekMonthCl', config.weekMonthCl);
document.documentElement.style.setProperty('--tempNameCl', config.tempNameCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--weNameCl', config.weNameCl);

/* On off */
if(!config.Ae){
document.getElementById('ClockAe').style.display = 'none';
document.getElementById('CalAe').style.display = 'none';
document.getElementById('TempAe').style.display = 'none';
document.getElementById('WeAe').style.display = 'none';
}

/* Other */
document.getElementById('ClockName').innerHTML = clocktext;
document.getElementById('CalName').innerHTML = caltext;
document.getElementById('TempName').innerHTML = temptext;
document.getElementById('WeName').innerHTML = wetext;