function mainUpdate(type){ 
if (type === "weather"){ checkWeather(); }
}

function checkWeather(){
document.getElementById("Condition").innerHTML = weather.temperature + '&deg;' + ' &nbsp' + condition[weather.conditionCode];
}