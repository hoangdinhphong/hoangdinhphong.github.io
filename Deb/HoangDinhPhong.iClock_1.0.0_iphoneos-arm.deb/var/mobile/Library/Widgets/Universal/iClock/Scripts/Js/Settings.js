/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Color */
document.documentElement.style.setProperty('--clockCl', config.clockCl);

/* On off */
if(!config.gra){
document.getElementById('Clock').classList.remove('Gradient');
document.getElementById('Calendar').classList.remove('Gradient');
}