let fontFamily = new FontFace("FontSelect", `url('${config.fontSelect}') format("truetype")`);
fontFamily.load().then(function(loadedFont){
document.fonts.add(loadedFont);})