const twelve = document.querySelector('.Twelve');
twelve.textContent = '12';
const six = document.querySelector('.Six');
six.textContent = '6';

const nine = document.querySelector('.Nine');
nine.textContent = '9';
const three = document.querySelector('.Three');
three.textContent = '3';

const one = document.querySelector('.One');
one.textContent = '';
const seven = document.querySelector('.Seven');
seven.textContent = '';

const two = document.querySelector('.Two');
two.textContent = '';
const eight = document.querySelector('.Eight');
eight.textContent = '';

const four = document.querySelector('.Four');
four.textContent = '';
const ten = document.querySelector('.Ten');
ten.textContent = '';

const five = document.querySelector('.Five');
five.textContent = '';
const eleven = document.querySelector('.Eleven');
eleven.textContent = '';

//const sec = document.animate(Spring(100, 20));

document.documentElement.style.setProperty('--hourCl', window.config.hourCl);

document.documentElement.style.setProperty('--minCl', window.config.minCl);

document.documentElement.style.setProperty('--secCl', window.config.secCl);

document.documentElement.style.setProperty('--numCl', window.config.numCl);

document.documentElement.style.setProperty('--hourMarCl', window.config.hourMarCl);

document.documentElement.style.setProperty('--brCenCl', window.config.brCenCl);

document.documentElement.style.setProperty('--bgCenCl', window.config.bgCenCl);

document.documentElement.style.setProperty('--brBgOutCl', window.config.brBgOutCl);

document.documentElement.style.setProperty('--brBgInCl', window.config.brBgInCl);

document.documentElement.style.setProperty('--bgInCl', window.config.bgInCl);

document.documentElement.style.setProperty('--dateCl', window.config.dateCl);

document.documentElement.style.setProperty('--dateBgCl', window.config.dateBgCl);

document.documentElement.style.setProperty('--brBgIn', `${window.config.brBgIn}%`);

document.documentElement.style.setProperty('--brBgOut', `${window.config.brBgOut}%`);

(function () {
document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=' + window.config.scale + ', maximum-scale=' + window.config.scale + ', user-scalable=0');
}());