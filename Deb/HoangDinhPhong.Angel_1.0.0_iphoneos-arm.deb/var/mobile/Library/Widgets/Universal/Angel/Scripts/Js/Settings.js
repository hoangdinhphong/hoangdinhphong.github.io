/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Other */
document.getElementById('Wing').src = 'Scripts/Wing/' + config.wingWall + '.png';
document.documentElement.style.setProperty('--sh', config.sh);
document.documentElement.style.setProperty('--pixel', config.pixel + 'px');
document.documentElement.style.setProperty('--halo', config.halo + 'px');

/* Color */
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--borCl', config.borCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--lineCl', config.lineCl);
document.documentElement.style.setProperty('--weekCl', config.weekCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--dateBgCl', config.dateBgCl);
