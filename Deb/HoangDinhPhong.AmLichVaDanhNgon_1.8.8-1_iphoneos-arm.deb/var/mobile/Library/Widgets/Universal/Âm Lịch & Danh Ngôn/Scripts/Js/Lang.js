Lang = lang;
if (Lang == "vi") {
var days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var months = ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"];
var amlichtext = "Âm lịch: ";
var monthtext = "tháng ";
var yeartext = "";
var battext = "Pin ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Độ ẩm ";
var windtext = "✫ Gió ";
var raintext = "Mưa ";
var uptext = "Cập nhật lúc ";
var Gan = new Array ("giáp", "ất", "bính", "đinh", "mậu", "kỷ", "canh", "tân", "nhâm", "quý");
var Zhi = new Array (" tí", " sửu", " dần", " mão", " thìn", " tị", " ngọ", " mùi", " thân", " dậu", " tuất", " hợi");
var artisttext = "Không có nghệ sĩ";
var titletext = "♫ Music ♫";
var condition = ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
}

if (Lang == "en") {
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var battext = "Battery ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Humidity ";
var windtext = "✫ Wind ";
var raintext = "Rain ";
var monthtext = "month ";
var yeartext = "year ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" rat", " ox", " tiger", " cat", " dragon", " snake", " horse", " goat", " monkey", " rooster", " dog", " pig");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunderstorms", "Thunderstorms", "Mixed rain and snow", "Mixed rain and sleet", "Mixed snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunderstorms", "Scattered thunderstorms", "Scattered thunderstorms", "Scattered showers", "Heavy snow", "Scattered snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Isolated thundershowers", "Not available"];
}

if (Lang == "sp") {
var days = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"];
var months = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
var battext = "Bateria ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Umidade ";
var windtext = "✫ Vento ";
var raintext = "Chuva ";
var monthtext = "mês ";
var yeartext = "ano ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" rato", " búfalo", " tigre", " gato", " dragão", " rato", " cavalo", " cabra", " macaco", " galinha", " cão", " porco");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tormenta tropical", "Huracan", "Tormentas electricas severas", "Tormentas electricas", "mezcla de lluvia y nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible"];
}

if (Lang == "de") {
var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
var months = ["januar", "februar", "märz", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "dezember"];
var battext = "Batterie ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Feuchtigkeit ";
var windtext = "✫ Wind ";
var raintext = "Regen ";
var monthtext = "monat ";
var yeartext = "jahr ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" maus", " büffel", " tiger", " katze", " drache", " maus", " pferd", " ziege", " affe", " huhn", " hund", " schwein");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tropischer sturm", "Wirbelsturm", "Schwere gewitter", "Gewitter", "Regen und schnee", "Graupelschauer", "Schneeregen", "Gefrierender nieselregen", "Nieselregen", "Gefrierender regen", "Schauer", "Schauer", "Schneegestöber", "Leichte schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "Stürmisch", "Windig", "Kalt", "Bewölkt", "Meist Bewölkt", "Meist Bewölkt", "Bewölkt", "Bewölkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und hagel", "Heiss", "Örtliche gewitter", "Vereinzelte gewitter", "Vereinzelte gewitter", "Vereinzelte schauer", "Starker schneefall", "Vereinzelte schneeschauer", "Starker schneefall", "Bewölkt", "Gewitter", "Scheeschauer", "Örtliche gewitterschauer", "Nicht verfügbar"];
}

if (Lang == "fr") {
var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
var months = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
var battext = "La batterie ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Humidité ";
var windtext = "✫ Vent ";
var raintext = "Pluie ";
var monthtext = "Mois ";
var yeartext = "An ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Souris", " Bufle", " Tigre", " Chat", " Dragon", " Souris", " Cheval", " Chèvre", " Singe", " Poulet", " Chien", " Cochon");
var titletext = "♫ Music ♫";
var condition = ["Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "Grêle", "Neige Fondue", "Poussiéreux", "Brouillard", "Brume", "Brumeux", "Tempête", "Vent", "Temps Froid", "Temps Nuageux ", "Très Nuageux", "Très Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleillé", "Beau Temps", "Beau Temps", "Pluie et Grêles", "Temps Chaud", "Orages Isolés", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages Isolés", "Non Disponible"];
}

if (Lang == "ru") {
var days = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
var months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
var battext = "Аккумулятор ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Влажность ";
var windtext = "✫ Ветер ";
var raintext = "Дождь ";
var monthtext = "Месяц ";
var yeartext = "Год ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Мышь", " Буйвол", " Тигр", " Кот", " Дракон", " Мышь", " Лошадь", " Коза", " Обезьяна", " Курица", " Собака", " Свинья");
var titletext = "♫ Music ♫";
var condition = ["Торнадо", "Тропический шторм", "Ураган", "Гроза", "Гроза", "Снег", "Мокрый снег", "Мокрый снег", "Изморозь", "Морось", "Ледяной дождь", "Ливень", "Ливень", "Сильные порывы ветра", "Снег", "Снег", "Снег", "Град", "Мокрый снег", "Пыль", "Туман", "Легкий туман", "Туманно", "Порывисто", "Ветренно", "Холодно", "Облачно", "Облачно", "Облачно", "Облачно", "Облачно", "Ясно", "Солнечно", "Ясно", "Ясно", "Мокрый снег", "Жарко", "Гроза", "Гроза", "Гроза", "Ливень", "Снегопад", "Небольшой снег", "Снегопад", "Переменная облачность", "Гроза", "Снег", "Гроза", "пусто"];
}

if (Lang == "nl") {
var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
var battext = "Accu ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Vochtigheid ";
var windtext = "✫ Wind ";
var raintext = "Regen ";
var monthtext = "Maand ";
var yeartext = "Jaar ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Muis", " Buffel", " Tijger", " Kat", " Draak", " Muis", " Paard", " Geit", " Aap", " Kip", " Hond", " Varken");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tropische Storm", "Orkaan", "Onweer", "Onweer", "Sneeuw", "Natte sneeuw", "Natte sneeuw", "Hagel", "Miezer", "Hagel", "Buien", "Buien", "Natte sneeuw", "Sneeuw", "Sneeuw", "Sneeuw", "Hagel", "Natte sneeuw", "Stof", "Mist", "Nevel", "Dampig", "Blustery", "Winderig", "Koud", "Bewolkt", "Bewolkt", "Bewolkt", "Bewolkt", "Bewolkt", "Helder", "Zon", "Normaal", "Normaal", "Natte sneeuw", "Heet", "Onweer", "Onweer", "Onweer", "Buien", "Zware sneeuw", "Lichte sneeuw", "Zware sneeuw", "Licht bewolkt", "Onweer", "Sneeuw", "Onweer", "blank"];
}

if (Lang == "cz") {
var days = ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"];
var months = ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"];
var battext = "Baterie ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Vlhkost vzduchu ";
var windtext = "✫ Vítr ";
var raintext = "Déšť ";
var monthtext = "Měsíc ";
var yeartext = "Rok ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Myš", " Buffalo", " Tygr", " Kočka", " Drak", " Myš", " Kůň", " Koza", " Opice", " Kuře", " Pes", " Prase");
var titletext = "♫ Music ♫";
var condition = ["Tornádo", "Tropická bouře", "Hurikán", "Bouře", "Bouře", "Sněžení", "Déšť a sníh", "Déšť a sníh", "Mrznoucí mrholení", "Mrholení", "Mrznoucí déšť", "Přeháňky", "Přeháňky", "Poryvy větru", "Sněžení", "Sněžení", "Sněžení", "Kroupy", "Déšť a sníh", "Prach", "Mlhy", "Řídké mlhy", "Kouř", "Větrno s bouřkami", "Větrno", "Chladno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Jasno", "Slunečno", "Krásně", "Krásně", "Déšť a sníh", "Horko", "Bouře", "Bouře", "Bouře", "Přeháňky", "Husté sněžení", "Lehké sněžení", "Husté sněžení", "Polojasno", "Bouře", "Sněžení", "Bouře", "prázdné"];
}

if (Lang == "it") {
var days = ['Domenica', 'Lunedi', 'Martedì', 'Mercoledì', 'Giovedi', 'Venerdì', 'Sabato'];
var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
var battext = "Batteria ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Umidità ";
var windtext = "✫ Vento ";
var raintext = "Pioggia ";
var monthtext = "Mese ";
var yeartext = "Anno ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Topo", " Bufalo", " Tigre", " Gatto", " Drago", " Topo", " Cavallo", " Capra", " Scimmia", " Pollo", " Cane", " Maiale");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tempesta Tropicale", "Uragano", "Temporali Forti", "Temporali", "Pioggia mista a Neve", "Nevischio", "Nevischio", "Pioggia Gelata", "Pioggerella", "Pioggia Ghiacciata", "Pioggia", "Pioggia", "Neve a Raffiche", "Neve Leggera", "Tempesta di Neve", "Neve", "Grandine", "Nevischio", "Irregolare", "Nebbia", "Foschia", "Fumoso", "Raffiche di Vento", "Ventoso", "Freddo", "Nuvoloso", "Molto Nuvoloso", "Molto Nuvoloso", "Nuvoloso", "Nuvoloso", "Sereno", "Sereno", "Bel Tempo", "Bel Tempo", "Pioggia e Grandine", "Caldo", "Temporali Isolati", "Temporali Sparsi", "Temporali Sparsi", "Rovesci Sparsi", "Neve Forte", "Nevicate Sparse", "Neve Forte", "Nuvoloso", "Rovesci Temporaleschi", "Rovesci di Neve", "Temporali isolati", "Non Disponibile"];
}

if (Lang == "tr") {
var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
var battext = "Batarya ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Nem ";
var windtext = "✫ Rüzgar ";
var raintext = "Yağmur ";
var monthtext = "Ay ";
var yeartext = "Yıl ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Fare", " Bufalo", " Kaplan", " Kedi", " Ejderha", " Fare", " At", " Keçi", " Maymun", " Tavuk", " Köpek", " Domuz");
var titletext = "♫ Music ♫";
var condition = ["Hortum", "Tropik Fırtına", "Kasırga", "Gök Gürültülü", "Gök Gürültülü", "Kar", "Karla Karışık Yağmur", "Karla Karışık Yağmur", "Kırağı", "Kırağı", "Dondurucu Yağmur", "Yağmur", "Yağmur", "Sağanak", "Kar", "Kar", "Kar", "Dolu", "Karla Karışık Yağmur", "Rüzgar", "Sis", "Puslu", "Sisli", "Sert", "Rüzgarlı", "Soğuk", "Bulutlu", "Bulutlu", "Bulutlu", "Bulutlu", "Bulutlu", "Açık", "Güneşli", "Açık", "Açık", "Sulu Kar", "Sıcak", "Gök Gürültülü", "Gök Gürültülü", "Gök Gürültülü", "Yağmur", "Ağır Kar", "Hafif Karlı", "Ağır Kar", "Parçalı Bulutlu", "Gök Gürültülü", "Kar", "Gök Gürültülü", "Boş"];
}

if (Lang == "es") {
var days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
var battext = "Batería ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Humedad ";
var windtext = "✫ Viento ";
var raintext = "Lluvia ";
var monthtext = "Mes ";
var yeartext = "Año ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Ratón", " Búfalo", " Tigre", " Gato", " Dragón", " Ratón", " Caballo", " Cabra", " Mono", " Pollo", " Perro", " Cerdo");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible"];
}

if (Lang == "he") {
var days = ["שבת", "שישי", "חמיש", "רביעי", "שלישי", "שני", "ראשון"];
var months = ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"];
var battext = "סוֹלְלָה ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ לחות ";
var windtext = "✫ רוּחַ ";
var raintext = "גֶשֶׁם ";
var monthtext = "חוֹדֶשׁ ";
var yeartext = "שָׁנָה ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array ("עכבר", "באפלו", "נמר", "חתול", "דרקון", "עכבר", "סוס", "עז", "קוף", "עוף", "כלב", "חזיר");
var titletext = "♫ Music ♫";
var condition = ["טורנדו", "סופה טרופית", "הוריקן", "סופת-רעמים", "סופת-רעמים", "שלג", "ברד קל", "ברד קל", "ברד", "טפטוף", "טפטוף", "מקלחת", "מקלחת", "משב רוח", "שלג", "שלג", "שלג", "ברד", "ברד קל", "Dust", "ערפל", "אובך", "אובך", "סוער", "סוער", "קר", "מעונן", "מעונן", "מעונן", "מעונן", "מעונן", "בהיר", "שמשי", "נאה", "נאה", "ברד קל", "חם", "סופת-רעמים", "סופת-רעמים", "סופת-רעמים", "מקלחת", "שלג כבד", "שלג קל", "שלג כבד", "מעונן חלקית", "סופת-רעמים", "שלג", "סופת-רעמים", "ריק"];
}

if (Lang == "pl") {
var days = ["Niedziela", "Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota"];
var months = ["Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien"];
var battext = "Bateria ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Wilgotność ";
var windtext = "✫ Wiatr ";
var raintext = "Deszcz ";
var monthtext = "Miesiąc ";
var yeartext = "Rok ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Mysz", " Bawół", " Tygrys", " Kot", " Smok", " Mysz", " Koń", " Koza", " Małpa", " Kurczak", " Pies", " Świnia");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tropikalna Burza", "Huragan", "Burza Z Piorunami", "Burza Z Piorunami", "Snieg", "Deszcz Ze Sniegiem", "Deszcz Ze Sniegiem", "Zamarzajaca Mzawka", "Mzawka", "Zamarzajacy Deszcz", "Przelotny Deszcz", "Przelotny Deszcz", "Przelotny Deszcz", "Snieg", "Snieg", "Snieg", "Grad", "Deszcz Ze Sniegiem", "Pyl", "Mgla", "Mgla", "Zadymiony", "Wietrznie", "Wietrznie", "Zimno", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Czyste Niebo", "Slonecznie", "Slonecznie", "Slonecznie", "Deszcz Ze Sniegiem", "Cieplo", "Burze z Piorunami", "Burze z Piorunami", "Burze z Piorunami", "Przelotny Deszcz", "Mocny Snieg", "Lekki Snieg", "Mocny Snieg", "Czesciowo Pochmurnie", "Burza Z Piorunami", "Snieg", "Burza Z Piorunami", "puste"];
}

if (Lang == "da") {
var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
var months = ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"];
var battext = "Batteri ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ Fugtighed ";
var windtext = "✫ Vind ";
var raintext = "Regn ";
var monthtext = "Måned ";
var yeartext = "År ";
var Gan = new Array ("", "", "", "", "", "", "", "", "", "");
var Zhi = new Array (" Mus", " Buffalo", " Tiger", " Cat", " Dragon", " Mouse", " Horse", " Ged", " Monkey", " Chicken", " Dog", " Pig");
var titletext = "♫ Music ♫";
var condition = ["Tornado", "Tropisk Storm", "Orkan", "Tordenvejr", "Tordenvejr", "Sne", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Raining", "Raining", "Flurries", "Snow", "Sne", "Sne", "Hagl", "Sleet", "Dust", "Tåge", "Dis", "Smoky", "Blustery", "Blæsende", "Koldt", "Overskyet", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Klart", "Solrigt", "Fair", "Fair", "Sleet", "Varmt", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Raining", "Tung sne", "Let sne", "Tung sne", "Delvist skyet", "Thunderstorm", "Sne", "Thunderstorm", "blank"];
}

if (Lang == "zh") {
var days = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
var months = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
var battext = "电池 ";
var charging = "⚡";
var notcharging = "";
var humtext = "✫ 湿度 ";
var windtext = "✫ 风 ";
var raintext = "雨 ";
var monthtext = "月 ";
var yeartext = "";
var Gan = new Array ("甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸");
var Zhi = new Array (" 鼠", " 牛", " 虎", " 兔", " 龙", " 蛇", " 马", " 羊", " 猴", " 鸡", " 狗", " 猪");
var titletext = "♫ Music ♫";
var condition = ["龙卷风", "热带风暴", "飓风", "雷暴", "雷暴", "雪", "雨夹雪", "雨夹雪", "有小冻雨", "细雨", "冻雨", "阵雨", "阵雨", "飘雪", "雪", "雪", "雪", "冰雹", "雨雪", "尘雾", "雾", "雾霾", "有雾", "大风", "有风", "冷", "多云", "多云", "多云", "多云", "多云", "晴朗", "晴天", "阴转晴", "阴转晴", "雨雪", "炎热", "雷暴", "雷暴", "雷暴", "淋浴", "大雪", "小雪", "大雪", "局部多云", "雷暴", "雪", "雷暴", "空白"];
}