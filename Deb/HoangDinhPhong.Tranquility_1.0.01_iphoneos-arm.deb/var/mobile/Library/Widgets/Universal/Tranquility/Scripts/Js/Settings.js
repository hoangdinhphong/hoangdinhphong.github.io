/* Other */
document.getElementById('YourName').innerHTML = config.YourName;
document.getElementById('Wel').innerHTML = weltext;
document.getElementById('Come').innerHTML = cometext;