var options = {};
var action = {};
action.savedElements = {};
action.containsWeather = false;
action.setOverlay = function (img) {
setTimeout(function () {
var screenOverDiv, svgdiv;
screenOverDiv = document.createElement('div');
screenOverDiv.className = 'screenOverlay';
screenOverDiv.style.backgroundImage = 'url(' + img + ')';
document.body.appendChild(screenOverDiv);
}, 0);
};

action.loadFromStorage = function () {
if (localStorage.placedElements) {
this.savedElements = JSON.parse(localStorage.placedElements);
if(this.savedElements.overlay != undefined){
if (this.savedElements.overlay.length > 1) {
if (!options.disableoverlay)
{ this.setOverlay(this.savedElements.overlay); }}}}};

function loadInfo(){
action.loadFromStorage();
}
setTimeout(function () {
loadInfo();
}, 0);
