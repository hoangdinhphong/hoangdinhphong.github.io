function mainUpdate(type){
if (type === "music"){checkMusic();
} else {
if (type === "weather"){checkWeather();
}}

/*----Weather----*/
function checkWeather(){
//document.getElementById("WeatherInfo").innerHTML = weather.naturalCondition;
document.getElementById("City").innerHTML = weather.city;
document.getElementById("WeatherInfo").innerHTML = condition[weather.conditionCode]  + '. ' + temptext + weather.temperature + '&deg; <br>' + humitext + weather.humidity + '%' + '. ' + windtext + weather.windSpeed + ' km/h' + '. ' + '<br>' + raintext +  weather.hourlyForecasts[0].percentPrecipitation + '%...';
document.getElementById('Day1').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.dayForecasts[1].icon + '.png';
document.getElementById('Day2').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[2].icon + ".png";
document.getElementById('Day3').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[3].icon + ".png";
document.getElementById('Day4').src = "Scripts/Weather/" + config.IconSet + '/' + weather.dayForecasts[4].icon + ".png";
}}

function checkMusic(){
if (isplaying === 1) {		document.getElementById('PlayPause').classList.remove("zeek-buttonplay");		document.getElementById('PlayPause').classList.add("zeek-buttonpause");
} else {		document.getElementById('PlayPause').classList.remove("zeek-buttonpause");		document.getElementById('PlayPause').classList.add("zeek-buttonplay");
}

if(title === "(null)"){
document.getElementById('Artist').innerHTML = artisttext;
document.getElementById('Title').innerHTML = titletext;
} else {
document.getElementById('Artist').innerHTML = artist;
document.getElementById('Title').innerHTML = title;

if (checkOverflow(document.getElementById('Title')) === true){
document.getElementById('Title').classList.add("marquee");
} else {
document.getElementById('Title').classList.remove("marquee");}
}

if(album === "(null)"){
document.getElementById('Album').src = 'Scripts/Js/Music.js';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Js/Music.js';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
}}}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ){
el.style.overflow = "hidden"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
el.style.overflow = curOverflow;
return isOverflowing; 
} 

function playPause() {
if(
document.getElementById('PlayPause').classList.contains("zeek-buttonplay")){ 
document.getElementById('PlayPause').classList.remove("zeek-buttonplay");
document.getElementById('PlayPause').classList.add("zeek-buttonpause");
} else { 
document.getElementById('PlayPause').classList.remove("zeek-buttonpause");
document.getElementById('PlayPause').classList.add("zeek-buttonplay");}

window.location = 'xeninfo:playpause';
document.getElementById('PlayPause').style.opacity = 0.4;
setTimeout(function (){
document.getElementById('PlayPause').style.opacity = 1;
}, 200);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Next').style.opacity = 0.4;
setTimeout(function (){
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Prev').style.opacity = 0.4;
setTimeout(function (){
document.getElementById('Prev').style.opacity = 1;
}, 200);
}