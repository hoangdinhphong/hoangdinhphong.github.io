document.documentElement.style.setProperty('--textStyle', config.textStyle);

/*On off*/
if(!config.Al){
document.getElementById('AmLich').style.display = 'none';
}