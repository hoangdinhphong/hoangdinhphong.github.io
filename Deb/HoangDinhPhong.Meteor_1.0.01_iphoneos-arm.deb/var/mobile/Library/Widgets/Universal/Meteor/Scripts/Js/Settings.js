/* Scale, shadow size & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Color */
document.documentElement.style.setProperty('--weekCl', config.weekCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--alCl', config.alCl);
document.documentElement.style.setProperty('--infoCl', config.infoCl);