var checkSettings= function() {}
checkSettings();
document.documentElement.style.setProperty('--heartCl', config.heartCl);
document.documentElement.style.setProperty('--timeDateCl', config.timeDateCl);
document.documentElement.style.setProperty('--infoCl', config.infoCl);
if(config.scale){
document.body.style.webkitTransform = 'scale(' + config.scale + ')';
document.getElementById('I').innerHTML = iText;}