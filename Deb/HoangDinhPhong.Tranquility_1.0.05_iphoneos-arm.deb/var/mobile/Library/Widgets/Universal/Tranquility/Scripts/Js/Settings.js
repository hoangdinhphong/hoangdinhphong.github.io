/* Other */
document.getElementById('YourName').innerHTML = config.YourName;
document.getElementById('Wel').innerHTML = weltext;
document.getElementById('Come').innerHTML = cometext;

/*Color*/
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--welCl', config.welCl);
document.documentElement.style.setProperty('--comeCl', config.comeCl);
document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--nextCl', config.nextCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);