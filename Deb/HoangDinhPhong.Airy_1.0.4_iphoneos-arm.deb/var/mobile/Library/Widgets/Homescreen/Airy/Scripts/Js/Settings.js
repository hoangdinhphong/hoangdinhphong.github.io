function HDP(){checkSettings();}
function checkSettings(){
if(!config.Apps){
document.getElementById('Apps').style.display = 'none';
}
if(!config.Cal){
document.getElementById('CalCont').style.display = 'none';
}}