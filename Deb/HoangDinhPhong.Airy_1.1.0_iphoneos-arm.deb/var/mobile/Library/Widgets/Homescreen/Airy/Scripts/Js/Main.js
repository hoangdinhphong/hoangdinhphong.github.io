var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 480) { iPhoneType = "iPh4"; }
else if (screen.height == 568) { iPhoneType = "iPh5"; }
else if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh4":
document.body.style.width='320px';
document.body.style.height='480px';
$("#Hour").css({ "top":"6%","font-size":"40px" });
$("#Minute").css({ "top":"45%","font-size":"40px" });
$("#AmLich").css({ "font-size":"7px" });

$("#Line").css({ "top":"110%" });
$("#Percent").css({ "font-size":"15px" });
$("#Charging").css({ "font-size":"9px" });
$("#Bat1").css({ "width":"16%","top":"39%","left":"29%" });
$("#Bl1, #Bl2").css({ "height":"11px" });
$("#BatName").css({ "top":"59%","font-size":"6px" });

$("#Temp").css({ "font-size":"12px" });
$("#Condition").css({ "font-size":"7px" });
$("#WeatherIcon").css({ "width":"38%" });

$("#Month").css({ "font-size":"11px" });
$("td, td.today").css({ "font-size":"8px" });
break;

case "iPh5":
document.body.style.width='320px';
document.body.style.height='568px';
$("#Hour").css({ "top":"6%","font-size":"50px" });
$("#Minute").css({ "top":"45%","font-size":"50px" });
$("#AmLich").css({ "font-size":"9px" });

$("#Line").css({ "top":"110%" });
$("#Percent").css({ "font-size":"20px" });
$("#Charging").css({ "font-size":"9px" });
$("#Bat1").css({ "width":"20%","top":"36.5%","left":"26%" });
$("#Bl1, #Bl2").css({ "height":"14px" });
$("#BatName").css({ "top":"59%","font-size":"8px" });

$("#Temp").css({ "font-size":"15px" });
$("#Condition").css({ "font-size":"9px" });
$("#WeatherIcon").css({ "width":"41%" });

$("#Month").css({ "font-size":"13px" });
$("td, td.today").css({ "font-size":"8px" });
break;

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#Hour").css({ "top":"6%","font-size":"65px" });
$("#Minute").css({ "top":"45%","font-size":"65px" });
$("#AmLich").css({ "font-size":"11px" });

$("#Line").css({ "top":"110%" });
$("#Percent").css({ "font-size":"25px" });
$("#Charging").css({ "font-size":"11px" });
$("#Bat1").css({ "width":"20%","top":"36.5%","left":"26%" });
$("#Bl1, #Bl2").css({ "height":"18px" });
$("#BatName").css({ "top":"59%","font-size":"10px" });

$("#Temp").css({ "font-size":"20px" });
$("#Condition").css({ "font-size":"11px" });
$("#WeatherIcon").css({ "width":"41%" });

$("#Month").css({ "font-size":"15px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#Hour").css({ "top":"6%","font-size":"65px" });
$("#Minute").css({ "top":"45%","font-size":"65px" });
$("#AmLich").css({ "font-size":"11px" });

$("#Line").css({ "top":"110%" });
$("#Percent").css({ "font-size":"25px" });
$("#Charging").css({ "font-size":"11px" });
$("#Bat1").css({ "width":"20%","top":"36.5%","left":"26%" });
$("#Bl1, #Bl2").css({ "height":"18px" });
$("#BatName").css({ "top":"59%","font-size":"10px" });

$("#Temp").css({ "font-size":"20px" });
$("#Condition").css({ "font-size":"11px" });
$("#WeatherIcon").css({ "width":"41%" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Hour").css({ "top":"6%","font-size":"65px" });
$("#Minute").css({ "top":"45%","font-size":"65px" });
$("#AmLich").css({ "font-size":"11px" });

$("#Line").css({ "top":"95%" });
$("#Percent").css({ "font-size":"27px" });
$("#Charging").css({ "font-size":"11px" });
$("#Bat1").css({ "width":"23%","top":"36.5%","left":"26%" });
$("#Bl1, #Bl2").css({ "height":"18px" });
$("#BatName").css({ "top":"59%","font-size":"10px" });

$("#Temp").css({ "font-size":"20px" });
$("#Condition").css({ "font-size":"11px" });
$("#WeatherIcon").css({ "width":"41%" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Line").css({ "top":"110%" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#Line").css({ "top":"90%" });
break;
}}, false);