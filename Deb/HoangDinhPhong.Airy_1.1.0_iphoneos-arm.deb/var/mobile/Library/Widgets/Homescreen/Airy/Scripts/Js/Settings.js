function HDP(){checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', config.br + 'px');

/*Color*/
document.documentElement.style.setProperty('--hourCl', config.hourCl);

document.documentElement.style.setProperty('--minuteCl', config.minuteCl);

document.documentElement.style.setProperty('--alCl', config.alCl);



document.documentElement.style.setProperty('--perCl', config.perCl);

document.documentElement.style.setProperty('--batNameBgCl', config.batNameBgCl);

document.documentElement.style.setProperty('--batNameCl', config.batNameCl);

document.documentElement.style.setProperty('--batCl', config.batCl);



document.documentElement.style.setProperty('--weBgCl', config.weBgCl);

document.documentElement.style.setProperty('--weCl', config.weCl);



document.documentElement.style.setProperty('--calCl', config.calCl);

document.documentElement.style.setProperty('--monthCl', config.monthCl);

document.documentElement.style.setProperty('--tabCl', config.tabCl);

/*On Off*/
if(!config.Apps){
document.getElementById('Apps').style.display = 'none';
}
if(!config.Cal){
document.getElementById('CalCont').style.display = 'none';
}}