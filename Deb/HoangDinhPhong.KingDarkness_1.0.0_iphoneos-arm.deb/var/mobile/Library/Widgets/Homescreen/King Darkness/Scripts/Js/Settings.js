function TTP(){checkSettings();}
function checkSettings(){

/*Color*/
document.documentElement.style.setProperty('--playBgCl', config.playBgCl);

document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--textCl', config.textCl);

document.documentElement.style.setProperty('--hiBgCl', config.hiBgCl);
document.documentElement.style.setProperty('--loBgCl', config.loBgCl);
document.documentElement.style.setProperty('--hiCl', config.hiCl);
document.documentElement.style.setProperty('--loCl', config.loCl);

document.documentElement.style.setProperty('--tempCl', config.tempCl);

document.documentElement.style.setProperty('--playTextCl', config.playTextCl);

document.documentElement.style.setProperty('--titleCl', config.titleCl);
document.documentElement.style.setProperty('--artistCl', config.artistCl);

document.documentElement.style.setProperty('--slideCl', config.slideCl);
document.documentElement.style.setProperty('--muTimeCl', config.muTimeCl);

document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--prevNextCl', config.prevNextCl);

document.documentElement.style.setProperty('--muIconCl', config.muIconCl);

/*Size & Border*/
document.documentElement.style.setProperty('--appBr', config.appBr + 'px');
document.documentElement.style.setProperty('--br', config.br + 'px');

document.documentElement.style.setProperty('--appX', config.appX + '%');
document.documentElement.style.setProperty('--appY', config.appY + '%');
document.documentElement.style.setProperty('--appH', config.appH + '%');

/*On of*/
if(!config.Se){
document.getElementById('SearchCont').style.display = 'none';
}
if(!config.App){
document.getElementById('AppCont').style.display = 'none';
}
if(!config.Hilo){
document.getElementById('HiloCont').style.display = 'none';
}
if(!config.We){
document.getElementById('WeCont').style.display = 'none';
}
if(!config.Text){
document.getElementById('TextCont').style.display = 'none';
}
if(!config.Mu){
document.getElementById('InfoCont').style.display = 'none';
document.getElementById('RemoteCont').style.display = 'none';
document.getElementById('AlbumCont').style.display = 'none';
}
document.getElementById("In").placeholder = config.ph;
}
