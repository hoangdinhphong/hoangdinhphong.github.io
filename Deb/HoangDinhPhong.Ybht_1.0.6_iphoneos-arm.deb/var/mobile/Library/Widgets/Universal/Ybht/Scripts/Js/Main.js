var changeSettings= function() {
document.getElementById("Battery").style.color = AllColor;
document.getElementById("Hour").style.color = AllColor;
document.getElementById("City").style.color = AllColor;}
changeSettings();
document.getElementById("Calendar").style.value = bulkhead;
document.documentElement.style.setProperty('--br', br + 'px');
document.documentElement.style.setProperty('--timeY', timeY + 'px');