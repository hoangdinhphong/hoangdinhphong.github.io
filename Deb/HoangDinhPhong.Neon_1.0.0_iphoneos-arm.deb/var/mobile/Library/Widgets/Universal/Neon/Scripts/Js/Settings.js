/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Color */
document.documentElement.style.setProperty('--textCl', config.textCl);
document.documentElement.style.setProperty('--weekCl', config.weekCl);

/* Om off */
if(!config.battWe){
document.getElementById('Condition').style.display = 'block';
document.getElementById('Percentage').style.display = 'none';
}

if(!config.hide){
document.getElementById('Condition').style.display = '';
document.getElementById('Percentage').style.display = 'none';
}