let fontFamily = new FontFace("FontSelect", `url(${'/Fonts/' + config.fontSelect + '.ttf'}) format("truetype")`);
fontFamily.load().then(function(loadedFont){
document.fonts.add(loadedFont);})