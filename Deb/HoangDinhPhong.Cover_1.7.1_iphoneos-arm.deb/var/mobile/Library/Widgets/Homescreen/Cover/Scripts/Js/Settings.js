/*---- PROPERTIES ----*/
document.documentElement.style.setProperty('--TextTransform', config.TextTransform);
document.documentElement.style.setProperty('--TextShadow', config.TextShadow);
document.documentElement.style.setProperty('--LetterSpacing', config.LetterSpacing + 'px');
document.documentElement.style.setProperty('--BlurWall', config.BlurWall + 'px');
document.documentElement.style.setProperty('--BlurOut', config.BlurOut + 'px');
document.documentElement.style.setProperty('--HuBl', config.HuBl + 'px');
document.documentElement.style.setProperty('--Br', config.Br + 'px');
document.documentElement.style.setProperty('--ShadowDockOverlay', config.ShadowDockOverlay + 'px');
document.documentElement.style.setProperty('--Transparency', config.Transparency);
document.documentElement.style.setProperty('--TransparencyDock', config.TransparencyDock);

/*---- ON OFF OTHER ----*/
if(!config.Name){
document.getElementById('YourName').style.display = 'none';
}
if(!config.StatusbarSh){
document.getElementById('Shadow').style.display = 'none';
}
if(!config.Skull){
document.getElementById('Skull').style.display = 'none';
document.getElementById('WeatherIcon').style.display = 'block';
}

/*---- LOCATION ----*/
document.documentElement.style.setProperty('--DayIconX', config.DayIconX + '%');
document.documentElement.style.setProperty('--NameX', config.NameX);
document.documentElement.style.setProperty('--ConditionX', config.ConditionX);
document.documentElement.style.setProperty('--DockY', config.DockY + '%');

/*---- COLOR ----*/
document.documentElement.style.setProperty('--BgCl', config.BgCl);
document.documentElement.style.setProperty('--Primary', config.C1);
document.documentElement.style.setProperty('--Secondary', config.C2);
document.documentElement.style.setProperty('--NameCl', config.NameCl);
document.documentElement.style.setProperty('--LightCl', config.LightCl);
document.documentElement.style.setProperty('--ConditionCl', config.ConditionCl);
document.documentElement.style.setProperty('--SubBgCl', config.SubBgCl);
document.documentElement.style.setProperty('--CityCl', config.CityCl);
document.documentElement.style.setProperty('--PlayCl', config.PlayCl);
document.documentElement.style.setProperty('--NextCl', config.NextCl);
document.documentElement.style.setProperty('--HuwiCl', config.HuwiCl);
document.documentElement.style.setProperty('--HuwiBgCl', config.HuwiBgCl);
document.documentElement.style.setProperty('--BatBgCl', config.BatBgCl);
document.documentElement.style.setProperty('--TitleCl', config.TitleCl);

/*---- CALENDAR ----*/
if(!config.Calendar){
document.getElementById('AmLich').style.display = 'block';
document.getElementById('Calendar').style.display = 'none';
}

/*---- MUSIC ----*/
if(!config.Artist){
document.getElementById('Artist').style.display = 'none';
}
if(!config.Album){
document.getElementById('AlbCont').style.display = 'none';
}
if(!config.Controls){
document.getElementById('Control').style.display = 'none';
}

/*---- WEATHER ----*/
if(!config.DayCont){
document.getElementById('DayCont').style.display = 'none';
}
if(!config.Condition){
document.getElementById('Condition').style.display = 'none';
}
if(!config.Shw){
document.getElementById('SubHumi').style.display = 'none';
document.getElementById('SubWind').style.display = 'none';
}
if(!config.Hilo){
document.getElementById('Hilo').style.display = 'none';
}
if(!config.Temp){
document.getElementById('Temp').style.display = 'none';
document.getElementById('Control').style.right = '17%';
document.getElementById('Control').style.width = '24%';
}
if(!config.Rain){
document.getElementById('Rain').style.display = 'none';
}

/*---- BATTERY ----*/
if(!config.Battery){
document.getElementById('Battery').style.display = 'none';
}

/*---- DOCK ----*/
if(!config.Dock){
document.getElementById('Dock').style.display = 'none';
document.getElementById('DockBlur').style.display = 'none';
}
if(!config.BorDock){
document.getElementById('DockBor').style.display = 'none';
}
if (window.config.Shadow == "in"){
document.getElementById('Dock').classList.remove('shadow-in');
document.getElementById('Dock').classList.add('shadow-out');
}

/*---- OTHER ----*/
document.documentElement.style.setProperty('--Sec', config.Sec + 's');
document.documentElement.style.setProperty('--Ro', config.Ro + 's');
document.getElementById('YourName').innerHTML = config.YourName;
document.getElementById("Shadow").src="Scripts/Js/Shadow.js";
document.getElementById("Ae").src="Scripts/Js/Ae.js";

/*---- MODE ----*/
if(!config.Full){
document.getElementById('Notch').style.height = '3%';
document.getElementById('Bor').style.width = '98%';
document.getElementById('WallCont').style.width = '94%';
document.getElementById('WallBlur').style.width = '94%';
document.getElementById('WallOverlay').style.width = '94%';
document.getElementById('Dock').style.width = '94%';

document.getElementById('Title').style.display = 'block';
document.getElementById('HuBg').style.display = 'block';
document.getElementById('Humi').style.display = 'block';
document.getElementById('WiBg').style.display = 'block';
document.getElementById('Wind').style.display = 'block';
document.getElementById('Rain').style.display = 'block';

document.getElementById('City').style.display = 'none';
document.getElementById('Hilo').style.display = 'none';
document.getElementById('Artist').style.display = 'none';
document.getElementById('Precip').style.display = 'none';
document.getElementById('SubHumi').style.display = 'none';
document.getElementById('SubWind').style.display = 'none';
document.getElementById('Subtitles').style.display = 'none';
}