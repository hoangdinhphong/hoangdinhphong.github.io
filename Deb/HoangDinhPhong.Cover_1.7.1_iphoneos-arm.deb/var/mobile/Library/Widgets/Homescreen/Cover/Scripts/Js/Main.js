var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 480) { iPhoneType = "iPh4"; }
else if (screen.height == 568) { iPhoneType = "iPh5"; }
else if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh4":
document.body.style.width='320px';
document.body.style.height='480px';
break;

case "iPh5":
document.body.style.width='320px';
document.body.style.height='568px';
break;

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#LightBulb").css({ "top":"-2%" });

$("#Humi, #Wind, #City, #Title, #HiLo, #Artist, #Rain").css({ "font-size":"9px" });
$("#YourName, #Condition, #Calendar, #AmLich").css({ "font-size":"11px" });

$("#HalfCircle").css({ "width":"68px", "height":"34px" });
$("#Circle").css({ "bottom":"10.5%", "width":"56px", "height":"56px" });

$("#Humi, #Wind").css({ "top":"79.1%" });
$("#Temp").css({ "font-size":"18px" });
$("#PlayPause").css({ "font-size":"19px" });
$("#Prev, #Next").css({ "font-size":"14px" });
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#LightBulb").css({ "top":"-1%" });
$("#Circle").css({ "bottom":"9.5%" });
$("#Humi, #Wind").css({ "top":"79.1%" });
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#LightBulb").css({ "top":"0%" });
$("#Circle").css({ "bottom":"10.3%" });
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#LightBulb").css({ "top":"0%" });
$("#Circle").css({ "bottom":"10.5%" });
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
$("#Circle").css({ "bottom":"11.3%" });
break;
}}, false);