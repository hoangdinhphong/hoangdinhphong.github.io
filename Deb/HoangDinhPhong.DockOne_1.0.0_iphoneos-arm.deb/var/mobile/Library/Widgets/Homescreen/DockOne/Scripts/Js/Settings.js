function HDP(){
checkSettings();

function checkSettings(){
document.documentElement.style.setProperty('--BrCl', config.BrCl);

document.documentElement.style.setProperty('--Style', config.Style);

document.documentElement.style.setProperty('--Size', config.Size + 'px');

document.documentElement.style.setProperty('--Bl', config.Bl + 'px');

document.documentElement.style.setProperty('--Br', config.Br + 'px');

document.documentElement.style.setProperty('--DockH', config.DockH + '%');

document.documentElement.style.setProperty('--DockW', config.DockW + '%');}
}