/* Scale, radius & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
document.documentElement.style.setProperty('--br', config.br + 'px');
document.documentElement.style.setProperty('--bl', config.bl + 'px');

/* Color */
document.documentElement.style.setProperty('--bgCl', config.bgCl);
document.documentElement.style.setProperty('--boCl', config.boCl);
document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
document.documentElement.style.setProperty('--cityCl', config.cityCl);
document.documentElement.style.setProperty('--conCl', config.conCl);
document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--hiCl', config.hiCl);
document.documentElement.style.setProperty('--loCl', config.loCl);
document.documentElement.style.setProperty('--lineCl', config.lineCl);
document.documentElement.style.setProperty('--dayCl', config.dayCl);
document.documentElement.style.setProperty('--hiloCl', config.hiloCl);
document.documentElement.style.setProperty('--yearCl', config.yearCl);

/* On off */
if(!config.Bg){
document.getElementById('Bg').style.display = 'none';
}
if(!config.Year){
document.getElementById('Year').style.display = 'none';
}