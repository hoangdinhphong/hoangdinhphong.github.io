/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Time Set */
document.documentElement.style.setProperty('--Sec', config.Sec + 's');
document.documentElement.style.setProperty('--Ro', config.Ro + 's');

/* Src */
document.getElementById("Ae").src="Scripts/Js/Ae.js";

/* Color */
document.documentElement.style.setProperty('--textCl', config.textCl);

document.documentElement.style.setProperty('--tempCl', config.tempCl);
document.documentElement.style.setProperty('--conCl', config.conCl);
document.documentElement.style.setProperty('--hiloCl', config.hiloCl);
document.documentElement.style.setProperty('--calCl', config.calCl);
document.documentElement.style.setProperty('--titleCl', config.titleCl);
document.documentElement.style.setProperty('--artCl', config.artCl);
document.documentElement.style.setProperty('--nextCl', config.nextCl);
document.documentElement.style.setProperty('--playCl', config.playCl);
document.documentElement.style.setProperty('--windIconCl', config.windIconCl);
document.documentElement.style.setProperty('--rainIconCl', config.rainIconCl);
document.documentElement.style.setProperty('--humiIconCl', config.humiIconCl);
document.documentElement.style.setProperty('--batteryIconCl', config.batteryIconCl);
document.documentElement.style.setProperty('--windCl', config.windCl);
document.documentElement.style.setProperty('--rainCl', config.rainCl);
document.documentElement.style.setProperty('--humiCl', config.humiCl);
document.documentElement.style.setProperty('--perCl', config.perCl);
document.documentElement.style.setProperty('--cenCl', config.cenCl);

/* Om off */
if(!config.Calendar){
document.getElementById('AmLich').style.display = 'block';
document.getElementById('Calendar').style.display = 'none';
}