function HDP(){checkSettings();}
function checkSettings(){
if(!config.Cal){
document.getElementById('CalCont').style.display = 'none';
}
}